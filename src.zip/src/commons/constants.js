export const { MONGO_CERT_BASE64 } = process.env 
export const { MONGO_URL } = process.env
export const { COLLECTION_NAME } = process.env
export const { PORCENTAJE_PRESTAMO } = process.env